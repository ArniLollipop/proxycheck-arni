Установи Inno Setup → https://jrsoftware.org/download.php/is.exe
Помести agent.exe в ту же папку, где лежит этот .iss файл.
Открой agent_installer.iss в Inno Setup Compiler.
Нажми Compile (F9).
В результате появится agent_installer.exe в папке Output.

ffa74505-b40e-4e40-a71d-0e4c379fb6f4